# Demande d'un nombre à l'utilisateur
nombre = int(input("Entrez un nombre : "))

# Boucle pour afficher les 10 nombres suivants
for i in range(1, 11):
    print(nombre + i)