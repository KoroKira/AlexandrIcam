# Pair Impair

nombre = int(input("Entrez un entier positif : "))

if nombre%2 == 0:
  print("PAIR")
else:
  print("IMPAIR")