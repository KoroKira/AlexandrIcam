a=int(input("donne un premier nombre"))
b=int(input("donne un second nombre"))

if a*b>=0:
    print("la multiplication est positive")

else:
    print("le résultat est négatif")